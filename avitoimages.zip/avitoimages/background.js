chrome.browserAction.onClicked.addListener(function(tab) {
   chrome.tabs.executeScript(null, {file: "script.js"});
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    
        if (tab.url.indexOf("avito") != -1) {
             
            chrome.tabs.executeScript(null, {file: "myScript.js"});
        }
    });