var func = function() {

    var imgs = document.getElementsByClassName('gallery-img-frame');
    
    for (index = 0, len = imgs.length; index < len; ++index) {
        var item = imgs[index];
    
        console.log(item);
    
        if(item.children != null && item.children.length >= 1) { 
            var lnk = document.createElement('a');
            lnk.setAttribute("href", "http:" + item.children[1].getAttribute('src'));
            lnk.setAttribute("download", "img.png");
    	    document.body.appendChild(lnk);
            lnk.click();
            lnk .remove();
        }
    }
      

}
func();


