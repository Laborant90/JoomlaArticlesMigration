 
var url =  document.URL;  
var date = JSON.stringify(new Date());
var storedLinks = {};
storedLinks[url] = date;

chrome.storage.sync.remove(url, function() {
    
});


chrome.storage.sync.set(storedLinks, function() {})

 /*
 красивый вариант, но не работает 
 var links = document.getElementsByClassName("item-description-title-link");
     
            for (index = 0, len = links.length; index < len; ++index) {
                var link = links[index];
                if(link.href != undefined) {
                    var href = link.href;
                    chrome.storage.sync.get(href, function(items) {
                        console.log(items);
                        var keys = Object.keys(items)
                        console.log(keys);
                        // var lnk = document.getElementsByTagName("a[href='"+ keys[0] + "']");
                        if(keys[0] != undefined && link != undefined ){ //lnk.innerText.indexOf("(Просмотрено)") != 0 ) {
                           
                            var lnks = document.getElementsByClassName("item-description-title-link");
                            for (index1 = 0, len = lnks.length; index1 < len; ++index1) {
                                if(lnks[index1].href == keys[0]  ) {
                                    if( link.innerText.indexOf("(Просмотрено)") != 0)
                                        link.innerText = "(Просмотрено)" + link.innerText;
                                    break;    
                                }    
                            }
                            
                        }
                    });
                }    
            } */
            

     chrome.storage.sync.get(null, function(items) {
            var allKeys = Object.keys(items);
             
            var links = document.getElementsByClassName("item-description-title-link");
     
            for (index = 0, len = links.length; index < len; ++index) {
                var link = links[index];
                if(link.href != undefined) {
                    var hasLink = false; 
                    var key = "";
                    for (index1 = 0, len = allKeys.length; index1 < len; ++index1) {
                        hasLink = (allKeys[index1] == "\"" + link.href + "\"" || allKeys[index1] ==  link.href  );
                        if(hasLink) { key = allKeys[index1]; break; }
                    }
                
                       
                    if(hasLink && link.innerText.indexOf("(Просмотрено)") != 0 ) {
                         
                         link.innerText = "(Просмотрено)" + link.innerText;
                    };
                }    
            }  
        }); 


     